//
//  lotteryCell.m
//  GrabEnvelope
//
//  Created by bai on 15-4-22.
//  Copyright (c) 2015年 bai. All rights reserved.
//

#import "lotteryCell.h"

@implementation lotteryCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
