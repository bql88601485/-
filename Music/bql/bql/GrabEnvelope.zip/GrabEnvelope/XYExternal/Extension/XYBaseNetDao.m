//
//  XYBaseNetDao.m
//  JoinShow
//
//  Created by Heaven on 14-9-10.
//  Copyright (c) 2014年 Heaven. All rights reserved.
//

#import "XYBaseNetDao.h"

@implementation XYBaseNetDao

@end
