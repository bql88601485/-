//
//  XYBaseService.m
//  JoinShow
//
//  Created by Heaven on 14-9-12.
//  Copyright (c) 2014年 Heaven. All rights reserved.
//

#import "XYBaseService.h"
#import "XYBaseDao.h"
#import "XYBaseNetDao.h"

@interface XYBaseService ()

@end

@implementation XYBaseService

@end
