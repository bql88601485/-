//
//  AutoSizeView.h
//  JC139house
//
//  Created by Jam on 13-3-11.
//  Copyright (c) 2013年 Jam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AutoSizeView : UIView

@end
