//
//  XYBlackMagic.m
//  JoinShow
//
//  Created by Heaven on 14/11/14.
//  Copyright (c) 2014年 Heaven. All rights reserved.
//

#import "XYBlackMagic.h"



@implementation XYBlackMagic

@end
