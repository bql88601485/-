//
//  XYMaterial.m
//  JoinShow
//
//  Created by Heaven on 14-1-17.
//  Copyright (c) 2014年 Heaven. All rights reserved.
//

#import "XYMaterial.h"

@implementation XYMaterial

@end
