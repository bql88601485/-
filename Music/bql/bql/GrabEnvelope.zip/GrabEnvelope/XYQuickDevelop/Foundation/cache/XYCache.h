//
//  XYCache.h
//  JoinShow
//
//  Created by Heaven on 14-1-21.
//  Copyright (c) 2014年 Heaven. All rights reserved.
//

#import "XYPrecompile.h"
// cache协议
#import "XYCacheProtocol.h"
// 内存缓存
#import "XYMemoryCache.h"
// 文件缓存
#import "XYFileCache.h"

// 数据缓存
#import "XYObjectCache.h"

// UserDefaults
#import "XYUserDefaults.h"
// Keychain
#import "XYKeychain.h"

// 归档
#import "XYAutoCoding.h"