//
//  XYProtocol.h
//  JoinShow
//
//  Created by Heaven on 14/11/4.
//  Copyright (c) 2014年 Heaven. All rights reserved.
//

#ifndef JoinShow_XYProtocol_h
#define JoinShow_XYProtocol_h

// 控制器协议
#import "XYControllerProtocol.h"

#endif
