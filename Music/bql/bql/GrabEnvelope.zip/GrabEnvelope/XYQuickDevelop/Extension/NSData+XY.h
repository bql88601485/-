//
//  NSData+XY.h
//  JoinShow
//
//  Created by Heaven on 13-10-16.
//  Copyright (c) 2013年 Heaven. All rights reserved.
//

#import "XYPrecompile.h"

@interface NSData (XY)

@property (nonatomic, readonly, strong) NSData          * MD5;
@property (nonatomic, readonly, strong) NSString        * MD5String;

@end
