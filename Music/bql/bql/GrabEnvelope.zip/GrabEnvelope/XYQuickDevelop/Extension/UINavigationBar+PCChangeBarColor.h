//
//  UINavigationBar+PCChangeBarColor.h
//  WaterCube
//
//  Created by bai on 15-1-27.
//  Copyright (c) 2015年 kevinzhow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (PCChangeBarColor)

-(void)changeBarColor;

@end
