//
//  NSNull+XY.h
//  JoinShow
//
//  Created by Heaven on 14-4-24.
//  Copyright (c) 2014年 Heaven. All rights reserved.
//

#import <Foundation/Foundation.h>
#pragma mark  todo 待验证
@interface NSNull (XY_InternalNullExtention)

@end
